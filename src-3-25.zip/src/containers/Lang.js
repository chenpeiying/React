import React, { Component } from 'react'

export default class Lang extends Component {
    render() {
        return (
            <div>
                设计语言
            </div>
        )
    }
}
