import React, { Component } from 'react'

export default class Gailan extends Component {
    render() {
        return (
            <div>
                概览
            </div>
        )
    }
}
