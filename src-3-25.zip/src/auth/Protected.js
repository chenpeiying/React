import React, { Component } from 'react'
function Protected(){
    return <h1>Protected</h1>
}
export default Protected;