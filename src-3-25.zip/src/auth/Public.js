import React from 'react';
function Public(){
    return <h1>Public</h1>
}
export default Public;